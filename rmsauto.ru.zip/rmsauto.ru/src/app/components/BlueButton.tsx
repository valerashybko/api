﻿import Styles from './BlueButton.module.scss';

export interface IBlueButton {
    type?: "submit" | "button" | "reset",
    disabled?: boolean;
    onClick?: (evt: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    title?: string;
    id?: string;
    //showSpinner?: boolean;
    alt?: string;
    //className?: string;
};

export interface IBlueLink {

    title?: string;
    id?: string;
    //showSpinner?: boolean;
    alt?: string;
    href: string;
    //isLink?: boolean;
    target?: string;
    //className?: "" | "width100" | "width100mobile";
    //download?: boolean;
    onClick?: (evt: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
}


const BlueLink: FC<IGreenLink> = ({
    title = "",
    id = "blue-link",
    //showSpinner,
    alt,
    //isLink = false,
    href,
    target = "_self",
    //className = "",
    onClick
}) => {


    return (
        <a id={id} href={href} target={target} onClick={onClick} className={Styles.blue__link}>
            <div className={Styles.blue__link__link} title={alt}>
                <div>{title}</div>
            </div>
        </a>
    );
};


const BlueButton: FC<IBlueButton> = ({
    type = "button",
    disabled = false,
    title = "",
    id = "blue-button",
    //showSpinner,
    onClick,
    alt,
    //className = "",
}) => {

    return (
        <a id={id} type={type} onClick={onClick} className={Styles.blue__button} disabled={disabled}>
            <div className={Styles.blue__button__button} title={alt}>
                <div>{title}</div>
            </div>
        </a>

        /*
        <button type={type} id={id} disabled={disabled} onClick={onClick} className={Styles.blue__button}>
            <div className={Styles.blue__button__button} title={alt}>
                <div>{title}</div>
            </div>
        </button>
        */
    );
};



export { BlueButton, BlueLink };