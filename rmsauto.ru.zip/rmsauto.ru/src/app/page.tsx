//import Image from "next/image";

export default function Home() {

    return (
        <div style={{ height: '660px', background: 'whitesmoke', padding: '24px' }}>
            <div>Search bar</div>
        </div>
    );
}
