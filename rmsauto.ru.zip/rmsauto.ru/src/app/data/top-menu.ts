﻿export type TTopMenu = {

    title: string,
    url: string
}

export const TopMenu: TTopMenu[] = [
    {
        title: "Оптовым покупателям",
        url: "https://rmsauto.ru/opt.aspx"
    },
    {
        title: "Поставщикам",
        url: "https://rmsauto.ru/suppliers.aspx"
    },
    {
        title: "Контакты",
        url: "https://rmsauto.ru/contacts.aspx"
    }
]

export const TopPanelPhone = {
    displayText: "+7 (495) 128-77-37",
    href: "tel:74951287737"
}