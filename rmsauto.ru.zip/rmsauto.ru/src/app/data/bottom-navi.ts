﻿export type TBottomMenu = {

    title: string;
    url: string;

};

export type TBottomNavi = {

    header: string;
    menu: TBottomMenu[]
};

export const BottomNavi: TBottomNavi[] = [
    {
        header: "Сервисы для клиентов",
        menu: [
            {
                title: "Доставка",
                url: "https://rmsauto.ru/deliveryorder.aspx"
            },
            {
                title: "Электронный документооборот",
                url: "https://rmsauto.ru/edo.aspx"
            },
            {
                title: "Гарантия и возврат",
                url: "https://rmsauto.ru/orderreturn.aspx"
            },
            {
                title: "API",
                url: "https://rmsauto.ru/api.aspx"
            },
            {
                title: "Оплата картой",
                url: "https://rmsauto.ru/paymenthelp.aspx"
            }
        ]

    },
    {
        header: "Информация",
        menu: [
            {
                title: "Оптовым покупателям",
                url: "https://rmsauto.ru/opt.aspx"
            },
            {
                title: "Поставщикам",
                url: "https://rmsauto.ru/suppliers.aspx"
            },
            {
                title: "Оферта",
                url: "https://rmsauto.ru/offer.aspx"
            },
            {
                title: "Помощь",
                url: "https://rmsauto.ru/help"
            }
        ]

    },
    {
        header: "О компании",
        menu: [
            {
                title: "Новости",
                url: "https://rmsauto.ru/news.aspx"
            },
            {
                title: "Вакансии",
                url: "https://rmsauto.ru/vacancies.aspx"
            }
        ]
    },
    {
        header: "Контакты",
        menu: [
            {
                title: "#",
                url: "https://t.me/RMSAUTOru"
            },
            {
                title: "Россия, 109028, Московская область, г.",
                url: ""
            },
            {
                title: "Мытищи, ул. Центральная, строение 20Б",
                url: ""
            },
            {
                title: "+7 (495) 128-77-37",
                url: "tel:74951287737"
            },
            {
                title: "info@rmsauto.ru",
                url: "mailto:info@rmsauto.ru"
            }
        ]
    }
]
