﻿export type TCardImage = {
    src: string;
    alt: string;
}

export const CardImages: TCardImage[] = [
    {
        src: "/paykeeper.webp",
        alt: "paykeeper"
    },
    {
        src: "/visa.webp",
        alt: "visa"
    },
    {
        src: "/mastercard.webp",
        alt: "mastercard"
    },
    {
        src: "/mir.webp",
        alt: "мир"
    }

];