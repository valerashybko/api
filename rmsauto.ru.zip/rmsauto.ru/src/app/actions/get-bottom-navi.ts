﻿'use server';

import { /*TBottomMenu,*/ BottomNavi, TBottomNavi } from '../data/bottom-navi';

export async function getBottomNavi(): Promise<TBottomNavi[]> {

    return BottomNavi;
}