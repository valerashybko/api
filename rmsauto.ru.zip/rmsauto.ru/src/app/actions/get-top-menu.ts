﻿'use server'

import { TopMenu, TTopMenu } from '../data/top-menu';

export async function getTopMenu(): Promise<TTopMenu[]> {

    return TopMenu;
}