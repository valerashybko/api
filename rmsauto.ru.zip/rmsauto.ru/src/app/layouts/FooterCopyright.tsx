﻿import Styles from './FooterCopyright.module.scss';
export function FooterCopyright() {

    return (
        <div className={Styles.footer__copyright_row}>
            © 2025 RMSAUTO.RU - Интернет-магазин запчастей для иномарок 
        </div>
    )
}