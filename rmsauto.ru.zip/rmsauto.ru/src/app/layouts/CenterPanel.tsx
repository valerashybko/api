﻿import { BasketPanel } from './BasketPanel';
import { LogoPanel } from './LogoPanel';

import Styles from './CenterPanel.module.scss'
export function CenterPanel() {

    return (
        <div className={Styles.center__panel__container}>
            <div className={Styles.center__panel__logo}><LogoPanel /></div>
            <div className={Styles.center__panel__basket}><BasketPanel /></div>
        </div>
    );
}