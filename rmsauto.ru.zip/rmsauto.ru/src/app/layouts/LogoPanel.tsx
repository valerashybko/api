﻿import Image from 'next/image';
import Styles from './LogoPanel.module.scss';
import { TopPanelPhone } from '../data/top-menu'
import { PhoneIco } from '../icons/PhoneIco'
export function LogoPanel() {

    return (

        <div className={Styles.logo__panel__container}>
            <div className={Styles.logo__panel__image}>
                <Image src="/rmsauto.png" width="78" height="76" alt="Нова"/>
            </div>
            <div className={Styles.logo__panel__rmsauto}>
                <span className={Styles.logo__panel__rmsauto_title}><b>Rms</b>Auto.ru</span>
                <span className={Styles.logo__panel__rmsauto_text}>Интернет-магазин</span>
            </div>
            <div className={Styles.logo__panel__phone}>
                <a href={TopPanelPhone.href}>
                    <div className={Styles.logo__panel__phone__phone}>
                        <PhoneIco height={28} width={28} />
                        {TopPanelPhone.displayText}
                    </div>
                </a>
            </div>
        </div>
    );
}