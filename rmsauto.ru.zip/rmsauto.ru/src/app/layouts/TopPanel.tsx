﻿import { TopMenu } from './TopMenu';
import { TopButtons } from './TopButtons';

import Styles from './TopPanel.module.scss';

export function TopPanel() {

    return (
        <div className={Styles.top__panel__container}>
            <div className={Styles.top__panel__menu}><TopMenu /></div>
            <div className={Styles.top__panel__buttons}><TopButtons /></div>
        </div>
    )
}