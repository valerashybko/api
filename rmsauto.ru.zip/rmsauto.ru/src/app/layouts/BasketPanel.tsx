﻿export function BasketPanel() {

    return (

        <div>Basket Panel</div>
    )
}