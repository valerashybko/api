﻿//import Image from 'next/image';
import { CardImages, TCardImage } from '../data/card-images';
import Styles from './FooterCardImages.module.scss'

function CardImage(image: TCardImage) {

    return (
        <div>
            <img src={image.src} alt={image.alt} />
        </div>
    );
}

export function FooterCardImages() {

    const images: TCardImage[] = CardImages;

    return (
        <div className={Styles.footer__card__image_row}>
            {images.map((image, index) => {

                return (<CardImage key={"Card_Image_" + index} {...image} />);

            })}
        </div>
    );
}