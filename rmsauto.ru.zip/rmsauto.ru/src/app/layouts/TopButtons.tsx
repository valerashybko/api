﻿import { BlueButton, BlueLink } from '../components/BlueButton';
import Styles from './TopButtons.module.scss';

export function TopButtons() {

    return (
        <div className={Styles.top__buttons__container}>
            <div className={Styles.top__buttons__item}>
                <BlueLink title="Регистрация" href="https://rmsauto.ru/cabinet/registration.aspx" />
            </div>
            <div className={Styles.top__buttons__item}>
                <BlueButton title="Вход" />
            </div>
            
            
        </div>
    )
}