﻿import { TopPanel } from './TopPanel'
import { CenterPanel } from './CenterPanel'

import Styles from './Header.module.scss'
export function Header() {


    return (
        /* 
        верхний блок: ширина 100%
        содеожимое: 1320px;
        */
        <div className={Styles.header__container}>
            <div className={Styles.header__top__panel__row}><TopPanel /></div>
            <div className={Styles.header__center__panel__row}><CenterPanel /></div>
        </div>
    );
}