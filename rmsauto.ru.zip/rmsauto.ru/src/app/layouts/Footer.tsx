﻿import Styles from './Footer.module.scss';

import { FooterNavi } from './FooterNavi';
import { FooterCardImages } from './FooterCardImages';
import { FooterCopyright } from './FooterCopyright';
export function Footer() {

    return (

        <div className={Styles.footer__container}>
            <div className={Styles.footer__row}>
                <FooterNavi />
                <FooterCardImages />
            </div>
            <div className={Styles.footer__copyright_row}>
                <FooterCopyright />
            </div>
        </div>
    );
}