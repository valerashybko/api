﻿//import Link from 'next/link';

import { getTopMenu } from '../actions/get-top-menu';
import Styles from './TopMenu.module.scss';

export async function TopMenu() {

    const topMenu = await getTopMenu();

    return (
        <ul className={Styles.top__menu__container}>
            {topMenu.map(menu => {
                return (
                    <li className={Styles.top__menu__item} key={menu.url}><a href={menu.url}>{menu.title}</a></li>
                );
            })}
        </ul>
    );
}