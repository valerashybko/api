﻿import { getBottomNavi } from '../actions/get-bottom-navi';
import { /*TBottomMenu,*/ TBottomNavi } from '../data/bottom-navi';

import Styles from './FooterNavi.module.scss';

function FooterNaviItem(item: TBottomNavi) {

    return (
        <div className={Styles.footer__navi__item}>
            <div className={Styles.footer__navi__item_header}>{item.header}</div>
            {item.menu.map((map, index) => {
                return (
                    <div className={Styles.footer__navi__item_link} key={"item_link_" + index}><a href={map.url}>{map.title}</a></div>
                );
            })}
        </div>
    );
}

export async function FooterNavi() {

    const navi: TBottomNavi[] = await getBottomNavi();

    return (
        <div className={Styles.footer__navi__row}>
            {navi.map(item => {
                return <FooterNaviItem key={item.header} {...item} />
            })}
        </div>
    );
}