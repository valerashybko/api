﻿export interface ISeoData {
    h1: string;
    title: string;
    description: string;
    keywords: string;
}
