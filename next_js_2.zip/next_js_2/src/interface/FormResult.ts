﻿export type FormSubmitResult = {
    success: boolean;
    message: string;
};