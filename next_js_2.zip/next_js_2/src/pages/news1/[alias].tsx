﻿import { useEffect, useState } from 'react';
import Head from 'next/head';
import { ISeoData } from '../../interface/ISeoData.ts';

interface IAlias {
    alias: string;
}
interface IContext {
    params: IAlias;
}

export async function getServerSideProps(context: IContext) {

    const { alias } = await context.params;

    const seo: ISeoData = {
        h1: 'This is H1',
        title: 'This is title',
        description: 'This is description',
        keywords: 'This is keywords'
    }

    return {
        props: {
            seo,
            alias
        }
    };
}

export default function NewsPage({ seo, alias }: { seo: ISeoData, alias: string}) {

    const [news, setNews] = useState('');

    useEffect(() => {

        setNews('News:' + alias);

    }, [alias]);

    return (
        <>
            <Head>
                <title>{seo.title}</title>
                <meta name="description" content={seo.description} />
                <meta name="keywords" content={seo.keywords} />
            </Head>
            <main>
                <h1>{seo.h1}</h1>

                {news && <div>{ news }</div> }
            </main>
        </>
    )
}

