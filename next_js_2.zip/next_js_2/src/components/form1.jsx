﻿'use client'

import SubmitButton from './submit-button';
import { createBlog } from '../actions/create-blog.ts';

const Form1 = () => {


    return (
        <form action={createBlog}>
            <h3>Add blog</h3>

            <div><input type="text" name="name"></input></div>

            <div><textarea name="text" rows="4"></textarea></div>

            <SubmitButton />
        </form>
    );
}

export default Form1;