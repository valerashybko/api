﻿'use client'

const SubmitButton = () => {

    return (
        <button type="submit">Submit</button>
    );
}

export default SubmitButton;