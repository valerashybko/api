﻿'use server'

import { revalidatePath } from "next/cache";

import { FormSubmitResult } from '../interface/FormResult.ts';

export async function createBlog(data: FormData): Promise<FormSubmitResult> {

    const name = data.get("name");
    const text = data.get("text");

    console.log('name >>>', name);
    console.log('text >>>', text);

    //await fetch("contoso.com");

    revalidatePath("page");

    return {
        success: true,
        message: ''
    };

}