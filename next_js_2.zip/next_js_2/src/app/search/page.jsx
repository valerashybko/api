﻿

export default function Search() {

    return (
        <>
            <div><input type="text"/></div>
            <div><button>Search</button></div>
        </>
    );
}