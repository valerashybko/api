﻿export default function NewsTemplate({ children }) {

    return (

        <div style={{ border: '1px dotted green', padding: '6px' }}>
            {children}
        </div>
    );
}