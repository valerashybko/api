﻿export default function NewsLayout({ children }) {

    return (
        <div style={{ border: '1px solid blue', padding: '6px' }}>
            <nav></nav>
            {children}
        </div>
    );
}