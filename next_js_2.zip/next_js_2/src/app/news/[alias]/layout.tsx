﻿export default function NewsPageLayout({ children }) {

    return (
        <div style={{ border: '1px solid red', padding: '6px' }} >
            {children}
        </div>
    )
}