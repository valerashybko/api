﻿//import { PageProps } from '../../../../.next/types/app/search/page.ts';
import { ISeoData } from '../../../interface/ISeoData.ts';


type TAlias = Promise<{ alias: string }>;

export async function generateMetadata({ params }: { params: TAlias }) {

    const { alias } = await params;
    const malias: string = unescape(alias);

    const seo: ISeoData = {
        h1: `This is H1 ${malias}`,
        title: `This is title ${malias}`,
        description: `This is description ${malias}`,
        keywords: `This is keywords ${malias}`
    };
    
    return seo;
}

export default async function Page({ params }: { params: TAlias }) {

    const { alias } = await params;
    const malias: string = unescape(alias);

    return (<>
        <h1>{ malias }</h1>
        <p>Post: {malias}</p>
    </>)
}
