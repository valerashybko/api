﻿import Form1 from '../../components/form1';

export default async function Blogs() {

    return (
        <>
            <h2>Blogs</h2>
            <Form1 />
        </>
    );
}